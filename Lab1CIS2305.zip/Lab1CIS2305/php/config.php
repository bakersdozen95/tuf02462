<?php
	define(DB_HOST, "cis-linux2.temple.edu");
	define(DB_USER, "tuf02462");
	define(DB_PASSWORD, "caiphiey");
	define(DB_DATABASE, "SP14_1052_tuf02462");
?>