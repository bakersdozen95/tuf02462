<?php
	print "Bad input, please try again.";
?>