<?php
	session_start();
	unset($_SESSION["ID"]);
	echo 1;
?>